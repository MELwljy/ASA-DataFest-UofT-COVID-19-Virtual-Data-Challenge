Team Members

1. Qianshu Ni: qianshu.ni@mail.utoronto.ca

2. Liangjiayi Wang: liangjiayi.wang@mail.utoronto.ca

3. Haoyue Tan: heather.tan@mail.utoronto.ca

4. Tianyang Li: derektianyang.li@mail.utoronto.ca



A slide deck/app (select one) was created, and is available at [https://github.com/DataFestUofT/submit-project-piazzzzahut/blob/master/DataFest%20-%20Slide%20Deck.pdf](https://github.com/DataFestUofT/submit-project-piazzzzahut/blob/master/DataFest - Slide Deck.pdf)

A slide video/write-up (select one) was created, and is available at [https://github.com/DataFestUofT/submit-project-piazzzzahut/blob/master/DataFest%20-%20Writeup.pdf](https://github.com/DataFestUofT/submit-project-piazzzzahut/blob/master/DataFest - Writeup.pdf)

